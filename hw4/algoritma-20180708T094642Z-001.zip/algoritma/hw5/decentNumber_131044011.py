# After eliminating dn < 3, dn % 3 == 0 and dn == 5

def decentNumber(dn):
    if dn < 3:
        return -1
    elif dn % 3 == 0:
        result = '5'
        for i in range(dn - 1):
            result += '5'
        return result
    elif dn == 5:
        return 33333
    else:
        current_number = '5'
        number_of_5 = 1
        result = '5'
        for i in range(dn - 1):
            if dn - i - 1 <= 5:
                current_number = '3'
            result += current_number
            number_of_5 += 1
        number_of_5 -= 5
        # print(number_of_5)
        if number_of_5 % 3 != 0:
            return - 1
        return result



dn = decentNumber(1)
print(dn)
#Output: -1
dn = decentNumber(3)
print(dn)
#Output: 555
dn = decentNumber(5)
print(dn)
#Output: 33333
dn = decentNumber(6)
print(dn)
#Output: 555555
dn = decentNumber(8)
print(dn)
#Output: 55533333
dn = decentNumber(10)
print(dn)
#Output: -1
dn = decentNumber(11)
print(dn)
#Output: 55555533333